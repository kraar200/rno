return {
Token = "5987845528:AAFHM4PUJRgixGQRECd-t8uCNt3sm7rkvyY",
UserBot = "vswqnbot",
UserSudo = "T_5_C",
SudoId = 611122715}
